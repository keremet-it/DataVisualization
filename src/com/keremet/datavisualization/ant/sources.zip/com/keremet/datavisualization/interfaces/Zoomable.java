/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.keremet.datavisualization.interfaces;

/**
 *
 * @author Владелец
 */
public interface Zoomable {
    public void zoom(float coeficient);
}
