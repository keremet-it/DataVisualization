/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.keremet.datavisualization.data;

import com.thoughtworks.xstream.XStream;
import java.util.Scanner;

/**
 *
 * @author Владелец
 */
public class DataGenerator {

    String fileName = "settings.txt";
    
    Scanner in;
    
    
    
    public DataGenerator() {
        
        XStream xs = new XStream(); 
        
        in = new Scanner(fileName);
        
        float chartsNumber = in.nextInt();
        
        float seriesLength = in.nextInt();
        
        for (int i=0; i< chartsNumber; i++) {
            //считываем возможные минимальные и максимальные значения для серии.
            
            float minValue = in.nextInt();
            float maxValue = in.nextInt();
            
            
            
        }
        
    }
}
